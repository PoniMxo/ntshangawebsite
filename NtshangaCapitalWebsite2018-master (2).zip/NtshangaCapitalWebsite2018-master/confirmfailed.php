<html>
<head>
        <title>Confirm Failed<title>
</head>
<body>
    <div>
        <h1>Failed to confirm your account please try again later.</h1>
    </div>
</body>
</html>