<?php 
$db = mysqli_connect("localhost","root","", "ntshanga_database")

?>