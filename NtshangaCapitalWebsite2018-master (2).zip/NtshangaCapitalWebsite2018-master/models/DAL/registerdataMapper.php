<?php
  class register{

 require 'dbConnection.php';
 require ''


  }





?>