<?php
    class errorlogger{
        
        public function GetErrorInfo($Error){

        }
    }
?>