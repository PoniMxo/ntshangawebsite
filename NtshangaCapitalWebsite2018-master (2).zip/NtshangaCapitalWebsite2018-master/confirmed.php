<html>
<head>
        <title>Confirm Successful<title>
</head>
<body>
    <div>
        <h1>Confirmed successfully.</h1>
        <div>
            <input type="submit" value="Go to profile" name="confirmedsuccessfully" />
        </div>
    </div>
</body>
</html>
<?php
header('Refresh: 2; profile.php')
?>